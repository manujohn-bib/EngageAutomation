package com.demoPOC.ViewCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.ExcelReader;
import com.demoPOC.helpers.Utils;

public class AddToCart extends BaseTest {

	// Login Page Objects Properties-Object Repository
	@FindBy(xpath = "//a[contains(.,'Tires Search')]")
	WebElement btnTireSearch;
	@FindBy(xpath = "//input[@id='SearchBarA']")
	WebElement txtMspn;
	@FindBy(xpath = "//input[@id='QuantitySearch']")
	WebElement txtqtySeacrh;
	@FindBy(xpath = "//button[contains(.,'SEARCH')]")
	WebElement btnSearch;
	@FindBy(xpath = ".//*[@id='quickorderTable']/tbody/tr[1]/td[7]/div/div[1]/div")
	WebElement btnClickAddCart;
	@FindBy(xpath = "//div[@class='inCartContainer']")
	WebElement imgCartQty;
	@FindBy(xpath = "//i[contains(@class,'cart')]")
	WebElement btnClickCart;
	@FindBy(xpath = "(.//td[@class='colCenterAlign'])[last()]//child::input")
	WebElement txtPONumber;
	@FindBy(xpath = "//button[contains(.,'CONFIRM ORDER')]")
	WebElement btnConfirmOrder;
	@FindBy(xpath = ".//label[@id='confirm_subTitle']")
	WebElement OrderConfirmationLoader;

	// Enter Login Details
	public void addToCart() throws Exception {
		txtMspn.sendKeys("63361");
		txtqtySeacrh.sendKeys("2");
		clickSearch();
		btnClickAddCart.click();
		btnClickCart.click();
		Thread.sleep(10000);
		System.out.println("Get Random Number"+ "445451" + Utils.getRandomNumber(4));
		(new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
				return txtPONumber.isDisplayed();
			}
		});

		txtPONumber.sendKeys("44545122" + Utils.getRandomNumber(4));

	}

	public void clickTireSearch() {
		btnTireSearch.click();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.findElement(By.xpath("//input[@id='SearchBarA']")).isDisplayed();

			}
		});
	}

	public void clickSearch() throws InterruptedException {
		Thread.sleep(1000);
		(new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
				return btnSearch.isDisplayed();
			}
		});
		btnSearch.click();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.findElement(By.xpath("//div[@class='invis']")).isDisplayed();

			}
		});

	}

	public void confirmOrder() throws InterruptedException {
		Thread.sleep(1000);
		(new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
				return btnConfirmOrder.isDisplayed();
			}
		});
		btnConfirmOrder.click();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.findElement(By
						.xpath(".//*[@id='NapiliCommunityTemplate']/div[1]/div/section/section[2]/div/div[1]/div/table/tbody/tr[1]/td[8]/div"))
						.isDisplayed();

			}
		});
	}

	public String getReferncenumber(){
		String refNumber = driver.findElement(By.xpath(".//*[@id='NapiliCommunityTemplate']/div[1]/div/section/section[2]/div/div[1]/div/table/tbody/tr[1]/td[8]/div")).getText().toString();
		return refNumber;

	}


	public void WaitForConfirmation()
	{
		(new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
				return OrderConfirmationLoader.isDisplayed();
			}
		});
	}

}