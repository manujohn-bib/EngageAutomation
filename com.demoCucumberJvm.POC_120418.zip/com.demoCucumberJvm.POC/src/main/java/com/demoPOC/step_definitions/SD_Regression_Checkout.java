package com.demoPOC.step_definitions;

import org.openqa.selenium.support.PageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.cucumber.listener.Reporter;
import com.demoPOC.ViewCases.CreateCase;
import com.demoPOC.basePageFactory.LoginPage;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.PropertyReader;

public class SD_Regression_Checkout extends BaseTest {
	// Load the Page Object Class Login
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	CreateCase viewcase = PageFactory.initElements(driver, CreateCase.class);

/*	@Given("^I am logged into Dealer Portal$")
	public void Iam_logged_into_Dealer_Portal() throws Throwable {

		try {
			login.LoginApplication(propertyReader.readTestData("userName"), propertyReader.readTestData("passWord"));
			login.CloseFavoritesPopUp();
			viewcase.clickViewCases();
			viewcase.clickNewCase();
			viewcase.clickDelivery();
			Reporter.addStepLog("Logged in to Dealer Portal ");
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reporter.addStepLog("Not Logged in to Dealer Portal " + e.getMessage().toString());
			e.printStackTrace();
		}

	}*/

}
