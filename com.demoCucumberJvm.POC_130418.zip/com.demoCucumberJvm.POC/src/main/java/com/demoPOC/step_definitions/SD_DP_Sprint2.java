package com.demoPOC.step_definitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.cucumber.listener.Reporter;
import com.demoPOC.ViewCases.AddToCart;
import com.demoPOC.ViewCases.CreateCase;
import com.demoPOC.basePageFactory.LoginPage;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.ExcelReader;
import com.demoPOC.helpers.PropertyReader;
import com.demoPOC.helpers.Utils;

public class SD_DP_Sprint2 extends BaseTest {
	// Load the Page Object Class Login
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	AddToCart addCart = PageFactory.initElements(driver, AddToCart.class);
	private String caseNum;
	@FindBy(xpath = ".//*[@id='billToDiv']/div/div[2]/div[1]/div/div/ul/li")
	WebElement listBillToAcnt;
	@FindBy(xpath = ".//*[@id='shipToDiv']/div/div[2]/div[1]/div/div/ul/li[2]")
	WebElement listShipToAcnt;

	@Given("^I am logged into Dealer Portal$")
	public void Iam_logged_into_Dealer_Portal() throws Exception {

		try {
			login.LoginApplication(propertyReader.readTestData("GLB_QA_URL"), propertyReader.readTestData("GlbuserName"),
					propertyReader.readTestData("GlbpassWord"));
			login.CloseFavoritesPopUp();
			Reporter.addStepLog("Logged in to Dealer Portal ");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reporter.addStepLog("Not Logged in to Dealer Portal " + e.getMessage().toString());
			e.printStackTrace();
		}

	}

	@And("^I have successfully conducted a Quick Order search$")
	public void I_have_successfully_conducted_a_Quick_Order_search() throws Exception {
		addCart.clickTireSearch();
		Reporter.addStepLog("Click on Tire Search ");

	}

	@And("^I have added products into my cart$")
	public void I_have_added_products_into_my_cart_() throws Exception {
		addCart.addToCart();
		Reporter.addStepLog("Add the cart ");

	}

	@When("^I confirm my order$")
	public void I_confirm_my_order_() throws Exception {
		
		addCart.confirmOrder();
		Reporter.addStepLog("Confirm the Order ");

	}

	@Then("^I should be redirected to the confirmation screen$")
	public void I_should_be_redirected_to_the_confirmation_screen() throws Exception
	{
		addCart.WaitForConfirmation();
		Assert.assertTrue(Utils.isTextPresent("Thank you for your order!"));
		addCart.getReferncenumber();
		Reporter.addStepLog("Verify the refernce number");
	}

}
