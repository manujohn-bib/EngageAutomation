package com.demoPOC.step_definitions;

import com.demoPOC.basePageFactory.LoginPage;
import com.demoPOC.basePageFactory.OPEPageFactory;
import com.demoPOC.basePageFactory.SFDCHomePage;
import com.demoPOC.basePageFactory.UATLoginPage;
import com.demoPOC.bdd.BaseTest;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class OpeStepDefinitions extends BaseTest {

    LoginPage login = PageFactory.initElements(driver, LoginPage.class);
    OPEPageFactory objOpe = PageFactory.initElements(driver, OPEPageFactory.class);


    @Given("^I am logged into the Dealer Portal$")
    public void i_am_logged_into_the_Dealer_Portal() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        login.LoginApplication(propertyReader.readTestData("opeusername"), propertyReader.readTestData("opepassword"));
    }

    @Given("^I have navigated to the notifications sections in the profile menu$")
    public void i_have_access_to_set_one_or_more_notifications_for_one_or_more_services() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objOpe.GotoProfilesMenu();
        objOpe.ClickOnNavigationsTab();
    }

    @When("^I have made changes to one or more notifications$")
    public void i_have_made_changes_to_one_or_more_notifications() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objOpe.ChangeNotificationStates();
    }

    @When("^I have clicked on the Save button$")
    public void i_have_clicked_on_the_Save_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objOpe.ClickSaveButton();
    }

    @Then("^the notification preferences will be saved$")
    public void the_notification_preferences_will_be_saved() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objOpe.VerifyifSaveButtonisClicked();
    }

    @Then("^those saved preferences will be there\\.$")
    public void when_I_log_back_into_the_Dealer_Portal_those_saved_preferences_will_be_there() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objOpe.CheckLabelStates();
    }
    @When("^I log back into the Dealer Portal$")
    public void when_I_log_back_into_the_Dealer_Portal() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        login.LoginApplication(propertyReader.readTestData("opeusername"), propertyReader.readTestData("opepassword"));
        objOpe.GotoProfilesMenu();
        objOpe.ClickOnNavigationsTab();
    }




}
