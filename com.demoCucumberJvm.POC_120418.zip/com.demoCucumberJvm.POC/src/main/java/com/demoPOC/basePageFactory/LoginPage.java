package com.demoPOC.basePageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.Utils;

public class LoginPage extends BaseTest {

	// Login Page Objects Properties-Object Repository
	@FindBy(xpath=".//input[@class='input sfdc_usernameinput sfdc input']")
	WebElement Username;
	@FindBy(xpath=".//input[@class='input sfdc_passwordinput sfdc input']")
	WebElement password;
	@FindBy(xpath=".//button[@class='sfdc_button uiButton--default uiButton']")
	WebElement SignInButton;
	@FindBy(css="button.sfdc_button")
	WebElement sfdcnext;
	@FindBy(css = "li.slds-context-bar__item:nth-child(5) > a:nth-child(1) > span:nth-child(1)")
	WebElement AccountsTab;
	@FindBy(xpath=".//img[@src='/resource/communityLibraries/assets/fav-onboard-icon-1.png']")
	WebElement OPEPageLoader;
	@FindBy(xpath=".//i[@class='mdp-icon__modal-close mdp-favorites-intro__close-icon']")
	WebElement CloseFavPopUp;
	@FindBy(xpath=".//input[@placeholder='Username']")
	WebElement FleetUsername;
	@FindBy(xpath=".//input[@placeholder='Password']")
	WebElement FleetPassword;
	@FindBy(xpath=".//button[@class='slds-button slds-button--brand loginButton uiButton--none uiButton']")
	WebElement FleetSignInButton;
	@FindBy(xpath=".//*[@id='siteHeading']")
	WebElement FleetProfilePageLoader;
	@FindBy(id="username")
	WebElement ServiceUsername;
	@FindBy(id="password")
	WebElement ServicePassword;
	@FindBy(id="Login")
	WebElement LoginButton;
	@FindBy(xpath=".//a[text()='Remind Me Later']")
	WebElement RemindMeLater;
	@FindBy(xpath=".//input[@title='Search Salesforce']")
	WebElement HomePageLoader;
	@FindBy(xpath = ".//*[@id='45:2;a']")
	WebElement Usernameqa;
	@FindBy(xpath = ".//*[@id='55:2;a']")
	WebElement passwordqa;
	@FindBy(xpath = "//button[contains(.,'SIGN IN')]")
	WebElement SignInButtonqa;
	//@FindBy(css = "i.mdp-icon__modal-close.mdp-favorites-intro__close-icon")
	//WebElement CloseFavPopUpqa;
	//@FindBy(css = "button.sfdc_button")
	//WebElement sfdcnextqa;

	// Enter Login Details
	public void LoginApplication(String Url, String username, String Password) throws Exception {
		driver.get(Repository.getProperty("GLB_QA_URL"));
		Utils.impliciteWait(35);
		Utils.writeText(Usernameqa, username);
		Utils.writeText(passwordqa, Password);
		SignInButtonqa.click();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return CloseFavPopUp.isDisplayed();
				//d.getCurrentUrl().contains("https://globalqa-partner-portal.cs88.force.com/s/favorites")

			}
		});
	}


	// Enter Login Details
	public void LoginApplication(String username, String Password) throws Exception {
		driver.get(Repository.getProperty("opeurl"));
		Utils.impliciteWait(5);
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--globaluat.cs83.my.salesforce.com/_nc_external/identity/saml/SamlError");
				return Username.isDisplayed();
			}
		});
		Utils.writeText(Username, username);
		Utils.writeText(password, Password);
		SignInButton.click();

		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.getCurrentUrl().contains("https://opeqatest-partner-portal.cs84.force.com/s/favorites");
				//return OPEPageLoader.isDisplayed();
			}
		});

//		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
//            public Boolean apply(WebDriver d) {
//                 //return d.getCurrentUrl().contains("https://empower--globaluat.cs83.my.salesforce.com/_nc_external/identity/saml/SamlError");
//                 return CloseFavPopUp.isDisplayed();
//            }
//        });
		try {
			WebDriverWait wait=new WebDriverWait(driver,150);
			wait.until(ExpectedConditions.elementToBeClickable(CloseFavPopUp));
			CloseFavoritesPopUp();
			Thread.sleep(5000);

		} catch (Exception e) {
			e.printStackTrace();
			Thread.sleep(10000);
		}

	}


	public void CloseFavoritesPopUp()
	{
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		try {
			CloseFavPopUp.click();
			Thread.sleep(5000);
			(new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver d) {
					//return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
					return CloseFavPopUp.isDisplayed();
				}
			});
			CloseFavPopUp.click();
		} catch (Exception e) {
		}
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void FleetLoginApplication(String username, String Password) throws Exception {
		driver.get(Repository.getProperty("fleeturl"));
		Utils.impliciteWait(5);
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--globaluat.cs83.my.salesforce.com/_nc_external/identity/saml/SamlError");
				return FleetUsername.isDisplayed();
			}
		});
		Utils.writeText(FleetUsername, username);
		Utils.writeText(FleetPassword, Password);
		FleetSignInButton.click();

		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://gportaldev-partner-portal.cs83.force.com/fleet/s/");
				return FleetProfilePageLoader.isDisplayed();
			}
		});

		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}

	}

	public void ServiceLogin(String username,String Password) throws Exception
	{
		driver.get(Repository.getProperty("serviceurl"));
		Utils.impliciteWait(5);
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--globaluat.cs83.my.salesforce.com/_nc_external/identity/saml/SamlError");
				return ServiceUsername.isDisplayed();
			}
		});
		Utils.writeText(ServiceUsername,username);
		Utils.writeText(ServicePassword, Password);
		LoginButton.click();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://gportaldev-partner-portal.cs83.force.com/fleet/s/");
				return RemindMeLater.isDisplayed();
			}
		});
		RemindMeLater.click();
		(new WebDriverWait(driver, 200)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://gportaldev-partner-portal.cs83.force.com/fleet/s/");
				return HomePageLoader.isDisplayed();
			}
		});
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
	}

}
