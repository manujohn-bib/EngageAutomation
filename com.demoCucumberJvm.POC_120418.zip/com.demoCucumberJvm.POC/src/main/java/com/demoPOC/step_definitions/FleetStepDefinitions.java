package com.demoPOC.step_definitions;

import com.demoPOC.basePageFactory.*;
import com.demoPOC.bdd.BaseTest;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class FleetStepDefinitions extends BaseTest
{

    LoginPage login = PageFactory.initElements(driver, LoginPage.class);
    OPEPageFactory objOpe = PageFactory.initElements(driver, OPEPageFactory.class);
    FleetpageFactory fleet=PageFactory.initElements(driver, FleetpageFactory.class);

    @Given("^I am logged into the fleet portal$")
    public void i_am_logged_into_the_fleet_portal() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        login.FleetLoginApplication(propertyReader.readTestData("fleetusername"), propertyReader.readTestData("fleetpassword"));;
        //login.ServiceLogin(propertyReader.readTestData("serviceusername"), propertyReader.readTestData("servicepassword"));
    }

    @Given("^I am in the Fleet Activities section of the Company Profile$")
    public void i_am_in_the_Fleet_Activities_section_of_the_Company_Profile() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        org.testng.Assert.assertTrue(fleet.VerifyIfFleetActivitiesSectionIsAvailalble());
    }

    @When("^I select a Vocation from the Vocations drop down$")
    public void i_select_a_Vocation_from_the_Vocations_drop_down() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fleet.selectVocationsValue("PEOPLE");
    }

    @Then("^I will be given the option to select an associated Usage from the Activities List drop down$")
    public void i_will_be_given_the_option_to_select_an_associated_Usage_from_the_Activities_List_drop_down() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fleet.CheckselectionfromFleetActivityDetailsTab("Urban People Transportation");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
