package com.demoPOC.basePageFactory;

import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.Utils;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class OPEPageFactory extends BaseTest {
    public static String[] strArr=new String[50];
    public static String[] strArrFinal=new String[50];


    // Login Page Objects Properties-Object Repository
    @FindBy(xpath=".//div[@class='mdp-main-header__profile-username']")
    WebElement ProfileName;
    @FindBy(xpath="(.//a[@class='mdp-main-header__profile-menu-item'])[1]")
    WebElement MyProfileLink;
    @FindBy(xpath=".//div[text()='Notifications']")
    WebElement NavigationsDivision;
    @FindBy(xpath="(.//div[@class='toggle-switch-control'])[1]")
    public WebElement ToggleButtonLoader;
//    @FindBy(xpath=".//div[@class='toggle-switch-control']")
//    public List<WebElement> ToggleButtons;
//    @FindBy(xpath=".//div[@class='toggle-switch-caption']")
//    public List<WebElement> ToggleButtonsLabels;
    @FindBy(xpath=".//div[@class='button-container margin-top padding-top']/child::button[text()='Save']")
    public WebElement SaveButton;

    LoginPage login = PageFactory.initElements(driver, LoginPage.class);

    public void GotoProfilesMenu() throws Exception
    {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Actions action = new Actions(driver);
        //action.moveToElement(ProfileName).click().build().perform();
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return ProfileName.isEnabled();
            }
        });
        try {
            ProfileName.click();
        } catch (Exception e) {
            login.CloseFavoritesPopUp();
        }
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return MyProfileLink.isEnabled();
            }
        });
        try {
            MyProfileLink.click();
        } catch (Exception e) {
            GotoProfilesMenu();        }
    }

    public void ClickOnNavigationsTab() throws Exception
    {
        try {
            Thread.sleep(5000);
            WebDriverWait wait=new WebDriverWait(driver,120);
            wait.until(ExpectedConditions.elementToBeClickable(NavigationsDivision));
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return NavigationsDivision.isDisplayed();
                }
            });
            NavigationsDivision.click();
        } catch (Exception e) {
            //e.printStackTrace();
            ClickOnNavigationsTab();
        }

    }

    public void ChangeNotificationStates() throws Exception
    {
        try {
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return ToggleButtonLoader.isDisplayed();
                }
            });
        } catch (Exception e) {
            ClickOnNavigationsTab();
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return ToggleButtonLoader.isDisplayed();
                }
            });
        }

        try {
            List<WebElement> ToggleButtons=driver.findElements(By.xpath(".//div[@class='toggle-switch-control']"));
            List<WebElement> ToggleButtonsLabels=driver.findElements(By.xpath(".//div[@class='toggle-switch-caption']"));
            Thread.sleep(15000);
            int i = 0,k=0;
            for (Iterator<WebElement> it = ToggleButtons.iterator(); it.hasNext(); i++) {
                    WebElement obj = it.next();
                    obj.click();
                    Thread.sleep(5000);
                }
        } catch (StaleElementReferenceException e) {
            ChangeNotificationStates();
        }
    }

    public void ClickSaveButton() throws Exception
    {
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return SaveButton.isDisplayed();
            }
        });
        if (SaveButton.isEnabled()){SaveButton.click();}
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void VerifyifSaveButtonisClicked() throws Exception
    {
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //ClickOnNavigationsTab();
        (new WebDriverWait(driver, 30)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return SaveButton.isDisplayed();
            }
        });
        Assert.assertFalse(SaveButton.isEnabled());
        Thread.sleep(10000);
        List<WebElement> ToggleButtonsLabels=driver.findElements(By.xpath(".//div[@class='toggle-switch-caption']"));
        int k=0;
        for (Iterator<WebElement> it1 = ToggleButtonsLabels.iterator(); it1.hasNext();)
        {
            //WebElement obj2 = it2.next();
            // System.out.println(it2.next().getText().toString());
            strArr[k]=it1.next().getText().toString();
            k++;
        }
        System.out.println(Arrays.toString(strArr));
    }

    public void CheckLabelStates() throws InterruptedException {
        Thread.sleep(10000);

        try {
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return ToggleButtonLoader.isDisplayed();
                }
            });
        } catch (Exception e) {
            try {
                ClickOnNavigationsTab();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return ToggleButtonLoader.isDisplayed();
                }
            });
        }
        Thread.sleep(10000);
        //List<WebElement> ToggleButtons=driver.findElements(By.xpath(".//div[@class='toggle-switch-control']"));
        List<WebElement> ToggleButtonsLabels=driver.findElements(By.xpath(".//div[@class='toggle-switch-caption']"));
        int k=0;
        for (Iterator<WebElement> it2 = ToggleButtonsLabels.iterator(); it2.hasNext();)
            {
                //WebElement obj2 = it2.next();
               // System.out.println(it2.next().getText().toString());
                strArrFinal[k]=it2.next().getText().toString();
                k++;
            }
        System.out.println(Arrays.toString(strArrFinal));


        Assert.assertEquals(strArrFinal,strArr);
    }

}
