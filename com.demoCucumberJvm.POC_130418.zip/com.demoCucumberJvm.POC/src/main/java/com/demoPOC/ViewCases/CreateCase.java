package com.demoPOC.ViewCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.ExcelReader;
import com.demoPOC.helpers.Utils;

public class CreateCase extends BaseTest {

	// Login Page Objects Properties-Object Repository
	@FindBy(xpath = ".//button[@class='new-case']")
	WebElement btnNewCase;
	@FindBy(xpath = ".//*[@id='shipToDiv']/div/div[2]/div[1]/div/a/span")
	WebElement listBillToAcnt;
	@FindBy(xpath = ".//*[@id='billToDiv']/div/div[2]/div[1]/div/a/span")
	WebElement listShipToAcnt;
	@FindBy(xpath = "//textarea[contains(@role,'textbox')]")
	WebElement txtDesc;
	@FindBy(xpath = "//div[3]/div/select")
	WebElement listFilterCaseType;
	@FindBy(xpath = "//div[5]/div[2]/select")
	WebElement lstdocumentType;
	@FindBy(id = "caseNumber")
	WebElement txtCaseNumber;
	@FindBy(id = "caseSubject")
	WebElement txtSubject;
	// _________________________________________________________________
	@FindBy(xpath = "//div[2]/select")
	WebElement caseReason;
	@FindBy(xpath = "//div[5]/div[2]/select")
	WebElement docType;
	@FindBy(css = "button.sfdc_button")
	WebElement sfdcnext;
	@FindBy(xpath = "(.//i[@class='mdp-main-nav__link-icon'])[last()]")
	WebElement btnViewCase;
	@FindBy(xpath = "//button[contains(.,'Delivery')]")
	WebElement btndelivery;
	@FindBy(xpath = "//div[contains(@class,'button-label')]")
	WebElement btnuploadFile;
	@FindBy(xpath = "//button[contains(.,'Submit Case')]")
	WebElement btnsubmitCase;
	@FindBy(xpath = "//div[@class='case-number']")
	WebElement imgCaseNumber;

	// Enter Login Details
	public void createNewCase(ExcelReader s, int i) throws Exception {

		WebElement shipto = driver.findElement(By.xpath(".//*[@id='shipToDiv']/div/div[2]/div[1]/div/a/span"));
		shipto.click();
		driver.findElement(By.xpath(".//*[@id='shipToDiv']/div/div[2]/div[1]/div/div/ul/li[2]")).click();
		WebElement billto = driver.findElement(By.xpath(".//*[@id='billToDiv']/div/div[2]/div[1]/div/a/span"));
		WebElement subject = driver.findElement(By.id("caseSubject"));

		billto.click();
		driver.findElement(By.xpath(".//*[@id='billToDiv']/div/div[2]/div[1]/div/div/ul/li")).click();

		txtSubject.sendKeys(s.getCellData("CreateCase", "Subject", i));
		Utils.selectOptionIfTextNotEmpty(s.getCellData("CreateCase", "CaseReason", i), caseReason);
		Utils.selectOptionIfTextNotEmpty(s.getCellData("CreateCase", "DocumentType", i), docType);
		Utils.writeText(txtDesc, s.getCellData("CreateCase", "Description", i) != null
				? s.getCellData("CreateCase", "Description", i) : "null");
		Utils.writeText(lstdocumentType, s.getCellData("CreateCase", "DocumentType", i) != null
				? s.getCellData("CreateCase", "DocumentType", i) : "null");
		Utils.writeText(txtCaseNumber, s.getCellData("CreateCase", "DocumentNumber", i) != null
				? s.getCellData("CreateCase", "DocumentNumber", i) : "null");
		Thread.sleep(1000);
		Utils.writeText(subject,"TestSubject");
		Thread.sleep(1000);
//		/Utils.fileUploadHandler("C:\\Users\\venkat.mareedu\\Desktop\\Touristplaces_Texas.txt");
		
		/*try {
			
			
			Utils.fileUploadHandler("C:\\Users\\venkat.mareedu\\Desktop\\Touristplaces_Texas.txt");
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}
		*/

		/*
		 * (new WebDriverWait(driver, 120)).until(new
		 * ExpectedCondition<Boolean>() { public Boolean apply(WebDriver d) {
		 * return d.getCurrentUrl().contains(
		 * "https://globalqa-partner-portal.cs88.force.com/s/favorites"); //
		 * return //
		 * d.findElement(By.cssSelector("button.sfdc_button")).isDisplayed(); }
		 * });
		 */

	}

	public void clickViewCases() {
		(new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				//return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
				return btnViewCase.isDisplayed();
			}
		});
		btnViewCase.click();
		driver.navigate().refresh();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.findElement(By.xpath("//h2[contains(.,'Case History Overview')]")).isDisplayed();

			}
		});

	}

	public void filterCaseType(String caseType) throws Exception {
		Utils.selectOptionIfTextNotEmpty(caseType, listFilterCaseType);
	}

	public void clickNewCase() {
		btnNewCase.click();
		(new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.findElement(By.xpath("//button[contains(.,'Delivery')]")).isDisplayed();

			}
		});
	}

	public void clickDelivery() throws InterruptedException {
		Thread.sleep(1000);
		btndelivery.click();
		Thread.sleep(2000);

	}

	public String getCaseNumber() {
		String caseNumber = imgCaseNumber.getText();
		return caseNumber;

	}

	public void clickSubmit() {
		btnsubmitCase.click();
	}
}