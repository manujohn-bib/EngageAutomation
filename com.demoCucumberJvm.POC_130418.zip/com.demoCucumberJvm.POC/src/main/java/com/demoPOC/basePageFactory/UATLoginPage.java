package com.demoPOC.basePageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.Utils;

public class UATLoginPage extends BaseTest {

    // Login Page Objects Properties-Object Repository
    @FindBy(css = "button.mb24")
    WebElement MyMichelinCredentialsLink;
    @FindBy(id = "Disp_Ecom_User_ID")
    WebElement Username;
    @FindBy(id = "Disp_Ecom_Password")
    WebElement Password;
    @FindBy(id = "loginButton2")
    WebElement SignInButton;
    @FindBy(xpath=".//button[@class='slds-button']")
    WebElement AppLauncher;

    // Enter Login Details
    public void UATLoginApplication(String username, String password) throws Exception {
        driver.get(Repository.getProperty("url"));
        Utils.impliciteWait(35);
        MyMichelinCredentialsLink.click();
        Utils.writeText(Username, username);
        Utils.writeText(Password, password);
        SignInButton.click();

        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                 return AppLauncher.isDisplayed();
            }
        });
        Thread.sleep(5000);

    }
}
