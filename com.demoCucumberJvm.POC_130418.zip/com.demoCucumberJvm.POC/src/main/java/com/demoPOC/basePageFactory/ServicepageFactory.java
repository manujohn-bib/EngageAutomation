package com.demoPOC.basePageFactory;

import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.ExcelReader;
import com.demoPOC.helpers.Utils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

public class ServicepageFactory extends BaseTest {
    ExcelReader s;
    public static String Subject1;
    @FindBy(xpath = ".//input[@title='Search Salesforce']")
    WebElement HomePageLoader;
    @FindBy(xpath = "(.//div[text()='New Case'])[1]")
    WebElement NewCaseButton;
    @FindBy(xpath = ".//input[@name='rec_type'][1]")
    WebElement RecordType;
    @FindBy(xpath = ".//button[@class='slds-button slds-button--neutral slds-button slds-button_brand uiButton slds-show']")
    WebElement NextButton;
    @FindBy(xpath = "(.//label[text()='Contact Name']//following::select)[1]")
    WebElement ContactNameDropdown;
    @FindBy(xpath = "(.//label[text()='Contact Name']//following::select)[2]")
    WebElement AssocoatedShipTOAccountDropdown;
    @FindBy(xpath = ".//label[text()='Subject']//following::input")
    WebElement Subject;
    @FindBy(xpath = "(.//a[@class='select'])[1]")
    WebElement InjuryorLegal;
    @FindBy(xpath = "(.//a[@class='select'])[2]")
    WebElement BusinessUnit;
    @FindBy(xpath = ".//a[text()='Case Details']")
    WebElement CaseCreationLoader;




    public void NavigateToAccount() throws InterruptedException {
        s=new ExcelReader(propertyReader.readTestData("datasheetpath"));
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return HomePageLoader.isDisplayed();
            }
        });
        int i=2;
        String AccountName;
        AccountName=s.getCellData("ServicePOC","AccountName",i);
        Utils.writeText(HomePageLoader,AccountName);
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("(.//mark[text()='" + AccountName + "'])[1]")).click();
        } catch (Exception e) {
           // e.printStackTrace();
            HomePageLoader.click();
            driver.findElement(By.xpath("(.//mark[text()='" + AccountName + "'])[1]")).click();
        }
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return NewCaseButton.isDisplayed();
            }
        });
    }

    public void ClickOnNewCase()
    {
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return NewCaseButton.isDisplayed();
            }
        });
        NewCaseButton.click();
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return RecordType.isDisplayed();
            }
        });

    }

    public void CreateNewCase() throws InterruptedException {
        s=new ExcelReader(propertyReader.readTestData("datasheetpath"));
        //NewCaseButton.click();
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return RecordType.isDisplayed();
            }
        });

        RecordType.click();
        NextButton.click();
        (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return ContactNameDropdown.isDisplayed();
            }
        });
        Select selv1=new Select(ContactNameDropdown);
        List<WebElement> contacts=selv1.getOptions();
        int i=1;
        for(WebElement we:contacts)
        {
            if(we.getText().toString().equalsIgnoreCase("--None--"))
            {
                //Do nothing
            }
            else
            {
                selv1.selectByIndex(i);
                break;
            }
            i++;
        }

        Select selv2=new Select(AssocoatedShipTOAccountDropdown);
        List<WebElement> accs=selv2.getOptions();
        int j=0;
        for(WebElement we1:accs)
        {
            if(we1.getText().toString().equalsIgnoreCase("--None--"))
            {
                //Do nothing
            }
            else
            {
                selv2.selectByIndex(j);
                break;
            }
            j++;
        }
        int k=2;

        Subject1=s.getCellData("ServicePOC","Subject",k);
        Utils.writeText(Subject,Subject1);
        InjuryorLegal.click();

        String InjuryOrLegal;
        InjuryOrLegal=s.getCellData("ServicePOC","InjuryOrLegal",i);
        Utils.writeText(HomePageLoader,InjuryOrLegal);
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.findElement(By.xpath(".//a[text()='"+InjuryOrLegal+"']")).click();

        Subject.click();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        BusinessUnit.click();

        String BusinessUnit;
        BusinessUnit=s.getCellData("ServicePOC","BusinessUnit",k);
        Utils.writeText(HomePageLoader,BusinessUnit);
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.findElement(By.xpath(".//a[text()='"+BusinessUnit+"']")).click();
        NextButton.click();
    }

    public void CheckIfCaseIsCreated()
    {
        try {
            (new WebDriverWait(driver, 60)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return CaseCreationLoader.isDisplayed();
                }
            });
            List <WebElement> CaseList=driver.findElements(By.xpath(".//span[text()='"+Subject1+"']"));
            Assert.assertNotNull(CaseList);
        } catch (Exception e) {
        }

    }
}