package com.demoPOC.step_definitions;

import com.cucumber.listener.Reporter;
import com.demoPOC.basePageFactory.FleetpageFactory;
import com.demoPOC.basePageFactory.LoginPage;
import com.demoPOC.basePageFactory.OPEPageFactory;
import com.demoPOC.basePageFactory.ServicepageFactory;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.Utils;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.ca.I;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;

public class ServiceStepDefinitions extends BaseTest {


    LoginPage login = PageFactory.initElements(driver, LoginPage.class);
    ServicepageFactory serv=PageFactory.initElements(driver,ServicepageFactory.class);

    @Given("^I am logged into the service portal$")
    public void i_am_logged_into_the_service_portal() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        login.ServiceLogin(propertyReader.readTestData("serviceusername"), propertyReader.readTestData("servicepassword"));
    }
    @And("^I am inside the site account tab$")
    public void i_am_insde_the_site_account_tab() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        serv.NavigateToAccount();
    }
    @When("^I click on New Case and provide all required inputs$")
    public void i_click_on_new_case_and_provide_all_required_inputs() throws Throwable {
        // Write code here serv.that turns the phrase above into concrete actions
        serv.ClickOnNewCase();
        serv.CreateNewCase();

    }
    @Then("^A new case should be created$")
    public void a_new_case_should_be_created() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        serv.CheckIfCaseIsCreated();
    }

}
