package com.demoPOC.step_definitions;

import com.demoPOC.basePageFactory.SFDCHomePage;
import com.demoPOC.basePageFactory.UATLoginPage;
import com.demoPOC.helpers.ExcelReader;
import org.openqa.selenium.support.PageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.cucumber.listener.Reporter;
import com.demoPOC.ViewCases.CreateCase;
import com.demoPOC.basePageFactory.LoginPage;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.PropertyReader;

public class POCStepDefinitions extends BaseTest
{
    UATLoginPage login = PageFactory.initElements(driver, UATLoginPage.class);
    SFDCHomePage home=PageFactory.initElements(driver, SFDCHomePage.class);
    LoginPage loginqa = PageFactory.initElements(driver, LoginPage.class);

    @Given("^Logged into Salesforce UAT environment$")
    public void logged_into_Salesforce_UAT_environment() throws Throwable {
       login.UATLoginApplication(propertyReader.readTestData("userName"), propertyReader.readTestData("passWord"));
        System.out.println(propertyReader.readTestData("userName"));
        System.out.println(propertyReader.readTestData("passWord"));
       // loginqa.LoginApplication(propertyReader.readTestData("userName"), propertyReader.readTestData("passWord"));
    }

    @When("^I click on create account link in the accounts tab of Salesforce$")
    public void click_on_create_account_link_in_the_accounts_tab_of_Salesforce() throws Throwable {
        home.CreateNewAccount();
    }

    @When("^Provide all neccessary inputs for account creation and click on Save button$")
    public void provide_all_neccessary_inputs_for_account_creation_and_click_on_Save_button() throws Throwable {
        home.SaveAccountAfterProvidingInput();
    }

    @Then("^Account should be successfully created$")
    public void account_should_be_successfully_created() throws Throwable {
        home.VerifyAccountCreation();
    }

    @When("^I click on Save button without providing any input$")
    public void click_on_Save_button_without_providing_any_input() throws Throwable {
        home.SaveAccountWithoutProvidingInput();
    }

    @Then("^Error messages should be validated$")
    public void Error_Message_Validations() throws Throwable {
        home.ErrorMessageVals();
    }


    @When("^I click on create new task link in the tasks tab of Salesforce$")
    public void i_click_on_create_new_task_link_in_the_tasks_tab_of_Salesforce() throws Throwable {
        home.GotoTaskCreationMenu();
    }

    @When("^click on Save task button after providing all neccessary inputs$")
    public void click_on_Save_task_button_after_providing_all_neccessary_inputs() throws Throwable {
        home.CreateNewTask();
    }

    @Then("^Task should be successfully created$")
    public void task_should_be_successfully_created() throws Throwable {
        home.VerifyIfTaskIsCreated();
    }

    @When("^Click on Task Save button without providing any input$")
    public void click_on_Task_Save_button_without_providing_any_input() throws Throwable {
        home.ClickSaveButton();
    }

}

