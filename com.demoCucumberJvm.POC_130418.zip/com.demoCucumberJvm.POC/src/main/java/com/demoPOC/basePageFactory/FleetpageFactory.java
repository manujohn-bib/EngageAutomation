package com.demoPOC.basePageFactory;

import com.demoPOC.bdd.BaseTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class FleetpageFactory extends BaseTest {
    @FindBy(xpath = ".//*[text()='Fleet Activities']")
    WebElement FleetActivitiesChecker;
    @FindBy(xpath = ".//div[@class='mfp-cmpprof-fleetact__vocations']//child::select")
    WebElement FleetVocationsDropdown;
    @FindBy(xpath = ".//label[text()='Activity Details']//following::select")
    WebElement FleetActivityDetailsDropdown;


    public Boolean VerifyIfFleetActivitiesSectionIsAvailalble() {
        try {
            (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--globaluat.cs83.my.salesforce.com/_nc_external/identity/saml/SamlError");
                    return FleetActivitiesChecker.isDisplayed();
                }
            });
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    public void selectVocationsValue(String vocations)
    {
        Assert.assertFalse(FleetActivityDetailsDropdown.isEnabled());
        Select sel=new Select(FleetVocationsDropdown);
        sel.selectByVisibleText(vocations);
    }

    public void CheckselectionfromFleetActivityDetailsTab(String activity)
    {
        Assert.assertTrue(FleetActivityDetailsDropdown.isEnabled());
        Select sel1=new Select(FleetActivityDetailsDropdown);
        sel1.selectByVisibleText(activity);
    }
}