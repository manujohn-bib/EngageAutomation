package com.demoPOC.step_definitions;

import org.testng.Assert;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.cucumber.listener.Reporter;
import com.demoPOC.ViewCases.CreateCase;
import com.demoPOC.basePageFactory.LoginPage;
import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.ExcelReader;
import com.demoPOC.helpers.PropertyReader;
import com.demoPOC.helpers.Utils;

public class SD_DP_Sprint1 extends BaseTest {
	// Load the Page Object Class Login
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	CreateCase viewcase = PageFactory.initElements(driver, CreateCase.class);
	
	private String caseNum;
	@FindBy(xpath = ".//*[@id='billToDiv']/div/div[2]/div[1]/div/div/ul/li")
	WebElement listBillToAcnt;
	@FindBy(xpath = ".//*[@id='shipToDiv']/div/div[2]/div[1]/div/div/ul/li[2]")
	WebElement listShipToAcnt;

	@Given("^I am logged into Dealer portal$")
	public void Iam_logged_into_Dealer_Portal() throws Exception {

		try {
			login.LoginApplication(propertyReader.readTestData("GLB_QA_URL"),
					propertyReader.readTestData("GlbuserName"), propertyReader.readTestData("GlbpassWord"));
			login.CloseFavoritesPopUp();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Reporter.addStepLog("Not Logged in to Dealer Portal " + e.getMessage().toString());
			e.printStackTrace();
		}

	}

	@And("^I have clicked on the Cases icon$")
	public void I_have_successfully_conducted_a_Quick_Order_search() throws Exception {
		viewcase.clickViewCases();
		viewcase.clickNewCase();
		Reporter.addStepLog("Click on Tire Search ");

	}

	@When("^I select Deleivery and fill in the Ship to, reason, description, document type and document number and upload a document$")
	public void I_have_added_products_into_my_cart_() throws Exception {
		viewcase.clickDelivery();
		Thread.sleep(5000);
		viewcase.createNewCase(Sprint1_Datasheet, 2);

		Reporter.addStepLog("Add the cart ");

	}

	@Then("^I click on Save, I have created a Delivery case draft.$")
	public void I_confirm_my_order_() throws Exception {
		viewcase.clickSubmit();
		Thread.sleep(20000);
		Assert.assertTrue(Utils.isTextPresent("Congratulations!"));
		caseNum = viewcase.getCaseNumber();

		// viewcase.createNewCase(Sprint1_Datasheet, 2);
		Reporter.addStepLog("Logged in to Dealer Portal ");
		Thread.sleep(5000);
		Reporter.addStepLog("Confirm the Order " + caseNum);

	}

}
