package com.demoPOC.basePageFactory;

import com.cucumber.listener.Reporter;
import com.demoPOC.helpers.ExcelReader;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.demoPOC.bdd.BaseTest;
import com.demoPOC.helpers.Utils;
import org.testng.Assert;

import java.util.Iterator;
import java.util.List;

public class SFDCHomePage extends BaseTest {
    ExcelReader s;
    // Login Page Objects Properties-Object Repository
    //@FindBy(xpath=".//a[@href='/one/one.app#/sObject/Account/home']")
    @FindBy(xpath="(.//a[@href='/one/one.app#/sObject/Account/home'])[1]")
    WebElement AccountsTab;
    @FindBy(xpath=".//div[text()='New']")
    WebElement AccountsNewLink;
    @FindBy(xpath = ".//input[@class='input uiInput uiInputText uiInput--default uiInput--input']")
    WebElement AccountName;
    @FindBy(css = "a.select")
    WebElement AccountCurrencyList;
    @FindBy(xpath = ".//a[@title='Indian Rupee']")
    WebElement SelectAccountCurrency;
    @FindBy(css = "button.forceActionButton:nth-child(3)")
    WebElement SaveButton;
    @FindBy(xpath = ".//select[@class=' select']")
    WebElement VehicleCategory;
    @FindBy(xpath = ".//button[@title='View Account Hierarchy']")
    WebElement AccountCreationVerifyElement;
    @FindBy(xpath = ".//span[@class='genericError uiOutputText']")
    WebElement ReviewErrorMessage1;
    @FindBy(xpath = ".//ul[@class='errorsList']")
    WebElement ReviewErrorMessage2;
    @FindBy(css = ".form-element__help")
    WebElement ReviewErrorMessage3;
    @FindBy(xpath=".//button[@class='slds-button']")
    WebElement AppLauncher;
    @FindBy(xpath=".//input[@class='slds-input input']")
    WebElement AppSearchBar;
    @FindBy(xpath=".//mark[text()='Tasks']")
    WebElement TaskSearchResult;
    @FindBy(xpath=".//mark[text()='Accounts']")
    WebElement AccountSearchResult;
    @FindBy(xpath=".//button[@class='slds-button slds-button--neutral slds-button slds-button--neutral uiButton forceActionButton']")
    WebElement NewTaskButton;
    @FindBy(xpath=".//span[text()='Standard']")
    WebElement RecordType;
    @FindBy(xpath=".//button[@class='slds-button slds-button--neutral uiButton--default uiButton--brand uiButton']")
    WebElement NextButton;
    @FindBy(xpath="(.//span[text()='Subject'])[last()]//parent::label//following-sibling::input")
    WebElement TaskSubject;
    @FindBy(xpath="(.//button[@title='Save'])[last()]")
    WebElement SaveTaskButton;

    // Enter Login Details
    public void CreateNewAccount() throws Exception {
       // AccountsTab.click();
        //AccountsNewLink.click();
        AppLauncher.click();
        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return AppSearchBar.isDisplayed();
            }
        });
        Utils.writeText(AppSearchBar,"Accounts");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            (new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return AccountSearchResult.isDisplayed();
                }
            });
        } catch (Exception e) {
            AppSearchBar.sendKeys(Keys.RETURN);
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return AccountSearchResult.isDisplayed();
                }
            });
        }
        AccountSearchResult.click();
        Thread.sleep(5000);

    }
    public void SaveAccountAfterProvidingInput() throws Exception {
        s=new ExcelReader(propertyReader.readTestData("datasheetpath"));
        //propertyReader.readTestData("datasheetpath")
        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return AccountsNewLink.isDisplayed();
            }
        });
        AccountsNewLink.click();
        int i=2;
        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return AccountName.isDisplayed();
            }
        });
        Utils.writeText(AccountName,s.getCellData("SFDCPOC","AccountName",i));
        AccountCurrencyList.click();
        SelectAccountCurrency.click();
        Select sel=new Select(VehicleCategory);
        sel.selectByVisibleText(s.getCellData("SFDCPOC","VehicleCategory",i));
        SaveButton.click();
    }

    public void VerifyAccountCreation() throws Exception{

        try {
            (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
        public Boolean apply(WebDriver d) {
            //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
            return AccountCreationVerifyElement.isDisplayed();
        }
    });
        } catch (Exception e) {

        }
        Assert.assertNotNull(AccountCreationVerifyElement);
    }

    public void SaveAccountWithoutProvidingInput() throws Exception {
        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return AccountsNewLink.isDisplayed();
            }
        });
        AccountsNewLink.click();
        SaveButton.click();
    }

    public void ErrorMessageVals() throws Exception {
        Assert.assertNotNull(ReviewErrorMessage1);
        Assert.assertNotNull(ReviewErrorMessage2);
        Assert.assertNotNull(ReviewErrorMessage3);
        System.out.println(ReviewErrorMessage1.getText().toString());
        System.out.println(ReviewErrorMessage2.getText().toString());
        System.out.println(ReviewErrorMessage3.getText().toString());

    }

    public void GotoTaskCreationMenu() throws Exception
    {
        AppLauncher.click();
        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return AppSearchBar.isDisplayed();
            }
        });
        Utils.writeText(AppSearchBar,"Tasks");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            (new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return TaskSearchResult.isDisplayed();
                }
            });
        } catch (Exception e) {
            AppSearchBar.sendKeys(Keys.RETURN);
            (new WebDriverWait(driver, 20)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return TaskSearchResult.isDisplayed();
                }
            });
        }
        TaskSearchResult.click();
        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return NewTaskButton.isDisplayed();
            }
        });
        NewTaskButton.click();
    }

    public void CreateNewTask() throws Exception
    {
        s=new ExcelReader(propertyReader.readTestData("datasheetpath"));
        try {
            (new WebDriverWait(driver, 30)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return RecordType.isDisplayed();
                }
            });
            RecordType.click();
            NextButton.click();
        } catch (Exception e) {
            Reporter.addStepLog("Record type popup is not available ");
        }

        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return TaskSubject.isDisplayed();
            }
        });
        Utils.writeText(TaskSubject,s.getCellData("SFDCPOC","TaskSubject",2));
        SaveTaskButton.click();
        Thread.sleep(5000);
    }

    public void VerifyIfTaskIsCreated() throws Exception{

        int TaskFound=0;

        List<WebElement> tasknames=driver.findElements(By.xpath("//span[@class='uiOutputText']"));
        Iterator<WebElement> it=tasknames.iterator();
        while (it.hasNext())
        {
            // Iterate one by one
            WebElement item = it.next();
            // get the text
            String label = item.getText();
            if(label.equalsIgnoreCase(TaskSubject.getText().toString()))
            {
                TaskFound=1;
                break;
            }
        }
        if(TaskFound == 1)
        {
            Reporter.addStepLog("Task is created succesfully");
        }
        else{
            Reporter.addStepLog("Task creation has failed");
        }

    }
    public void ClickSaveButton() throws Exception {
        try {
            (new WebDriverWait(driver, 30)).until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver d) {
                    //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                    return RecordType.isDisplayed();
                }
            });
            RecordType.click();
            NextButton.click();
        } catch (Exception e) {
            Reporter.addStepLog("Record type popup is not available ");
        }
        (new WebDriverWait(driver, 30)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                //return d.getCurrentUrl().contains("https://empower--uat.lightning.force.com/one/one.app#/home");
                return SaveTaskButton.isDisplayed();
            }
        });
        SaveTaskButton.click();
    }
}
